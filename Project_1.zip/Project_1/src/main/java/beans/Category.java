package beans;

public enum Category {
    Food,
    Electricity,
    Restaurant,
    Vacation
}
