package loginSystem;

public enum ClientType {
    Administrator,
    Company,
    Customer;
}
