package com.jb.project3.finalCouponSystem.mapper;

import com.jb.project3.finalCouponSystem.bins.dto.CouponDto;
import com.jb.project3.finalCouponSystem.bins.entity.Coupon;
import java.util.List;


public interface CouponMapper {
    CouponDto ToDTO(Coupon coupon);
    List<CouponDto> ListToDTO(List<Coupon> coupons);
    Coupon ToDAO(CouponDto couponDto);
    List<Coupon> ListToDAO(List<CouponDto> couponsDto);
}

