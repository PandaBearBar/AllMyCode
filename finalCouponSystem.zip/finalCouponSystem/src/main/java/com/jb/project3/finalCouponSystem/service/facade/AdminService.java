package com.jb.project3.finalCouponSystem.service.facade;

import com.jb.project3.finalCouponSystem.bins.dto.CompanyDto;
import com.jb.project3.finalCouponSystem.bins.dto.CouponDto;
import com.jb.project3.finalCouponSystem.bins.dto.CustomerDto;
import com.jb.project3.finalCouponSystem.excapt.CouponSystemException;

import java.util.List;

public interface AdminService {
    int getId(String email,String password);
    boolean login(String email,String password);

    void addCompany(CompanyDto companyDto) throws CouponSystemException;
    void updateCompany(int companyId, CompanyDto companyDto) throws CouponSystemException;
    void deleteCompany(int companyId) throws CouponSystemException;
    List<CompanyDto>getAllCompanies();
    CompanyDto getOneCompany(int companyId) throws CouponSystemException;

    void addCustomer(CustomerDto customerDto) throws CouponSystemException;
    void updateCustomer(int customerId, CustomerDto customerDto) throws CouponSystemException;
    void deleteCustomer(int customerId) throws CouponSystemException;
    List<CustomerDto>getAllCustomers();
    CustomerDto getOneCustomer(int customerId);
    List<CouponDto>getAllCoupons();

}
