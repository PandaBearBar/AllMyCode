package com.jb.project3.finalCouponSystem.service.loginSystem;

public enum ClientType {
    Administrator,
    Company,
    Customer;
}
