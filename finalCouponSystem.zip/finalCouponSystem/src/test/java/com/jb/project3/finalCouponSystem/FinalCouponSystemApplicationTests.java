package com.jb.project3.finalCouponSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalCouponSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
