package com.project.project2.bins;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@NoArgsConstructor
public enum Category {
    Food,
    Electricity,
    Restaurant,
    Vacation;
}
