package com.project.project2.service.loginSystem;

public enum ClientType {
    Administrator,
    Company,
    Customer;
}
