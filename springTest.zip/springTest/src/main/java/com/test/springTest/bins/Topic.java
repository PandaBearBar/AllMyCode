package com.test.springTest.bins;

public enum Topic {
    Project1,
    Project2,
    Project3;
}
